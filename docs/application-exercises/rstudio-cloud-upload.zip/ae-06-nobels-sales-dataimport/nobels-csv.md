Nobel winners
================
Mine Çetinkaya-Rundel, adapted by Lukas Jürgensmeier

``` r
library(tidyverse)
```

Let’s first load the data:

``` r
nobel <- ___(___)
```

Then let’s split the data into two:

``` r
# stem laureates
___ <- nobel %>%
  filter(___)

# non-steam laureates
___ <- nobel %>%
  filter(___)
```

And finally write (i.e. save) both data frames individually to the
`data` folder

``` r
# add code for saving both data frames here
```
